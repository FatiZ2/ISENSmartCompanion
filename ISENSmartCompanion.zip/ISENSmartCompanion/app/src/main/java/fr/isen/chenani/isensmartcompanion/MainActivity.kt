package fr.isen.chenani.isensmartcompanion

import android.app.Application
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.HiltAndroidApp
import fr.isen.chenani.isensmartcompanion.ui.theme.ISENSmartCompanionTheme
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET


// Application class for Hilt
@HiltAndroidApp
class MyApp : Application()

// Main Activity with Hilt support
@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ISENSmartCompanionTheme {
                AppNavigation()
            }
        }
    }
}

// Data model for an Event
data class Event(
    val id: String? = null,
    val title: String? = null,
    val description: String? = null,
    val date: String? = null,
    val location: String? = null,
    val imageUrl: String? = null
)

// Retrofit API interface
interface EventApiService {
    @GET("events.json")
    fun getEvents(): Call<List<Event>>
}

// Retrofit client
object EventRetrofitClient {
    private const val BASE_URL = "https://isen-smart-companion-default-rtdb.europe-west1.firebasedatabase.app/"

    val apiService: EventApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(EventApiService::class.java)
    }
}

// ViewModel to fetch and store events
class EventViewModel : ViewModel() {
    var events by mutableStateOf<List<Event>>(emptyList())
        private set

    fun fetchEvents() {
        EventRetrofitClient.apiService.getEvents().enqueue(object : Callback<List<Event>> {
            override fun onResponse(call: Call<List<Event>>, response: Response<List<Event>>) {
                if (response.isSuccessful) {
                    events = response.body() ?: emptyList()
                    Log.d("EventViewModel", "Événements chargés : ${events.size}")
                } else {
                    Log.e("EventViewModel", "Erreur de réponse : ${response.errorBody()?.string()}")
                }
            }

            override fun onFailure(call: Call<List<Event>>, t: Throwable) {
                Log.e("EventViewModel", "Erreur réseau : ${t.message}")
            }
        })
    }
}

// Composable function to display a single event
@Composable
fun EventItem(event: Event) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
            .background(Color.White, RoundedCornerShape(10.dp))
            .padding(16.dp)
    ) {
        Text(text = event.title ?: "Sans titre", style = MaterialTheme.typography.headlineSmall)
        Text(text = event.description ?: "Pas de description", style = MaterialTheme.typography.bodyLarge)
        Text(text = "Date : ${event.date}", style = MaterialTheme.typography.bodyMedium)
        Text(text = "Lieu : ${event.location}", style = MaterialTheme.typography.bodyMedium)
    }
}

// Composable function to display the list of events
@Composable
fun EventsScreen(viewModel: EventViewModel = hiltViewModel()) {
    val events = viewModel.events

    LaunchedEffect(Unit) {
        viewModel.fetchEvents()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "Événements à venir",
            style = MaterialTheme.typography.headlineMedium
        )
        Spacer(modifier = Modifier.height(16.dp))

        if (events.isEmpty()) {
            Text(text = "Aucun événement disponible", color = Color.Gray)
        } else {
            events.forEach { event ->
                EventItem(event = event)
            }
        }
    }
}

// Navigation setup for the application
@OptIn(ExperimentalMaterial3Api::class)

@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    Scaffold(
        bottomBar = { BottomNavigationBar(navController) }
    ) { innerPadding ->
        NavGraph(
            navController = navController,
            modifier = Modifier.padding(innerPadding)
        )
    }
}

// Define navigation graph
@Composable
fun NavGraph(navController: NavHostController, modifier: Modifier = Modifier) {
    NavHost(
        navController = navController,
        startDestination = "main",
        modifier = modifier
    ) {
        composable("main") { MainScreen() }
        composable("events") { EventsScreen() }
    }
}

// Bottom navigation bar
@Composable
fun BottomNavigationBar(navController: NavHostController) {
    NavigationBar {
        NavigationBarItem(
            icon = { Icon(Icons.Filled.Home, contentDescription = "Home") },
            label = { Text("Home") },
            selected = navController.currentDestination?.route == "main",
            onClick = {
                navController.navigate("main") {
                    popUpTo(navController.graph.startDestinationId)
                    launchSingleTop = true
                    restoreState = true
                }
            }
        )

        NavigationBarItem(
            icon = { Icon(Icons.Filled.Favorite, contentDescription = "Events") },
            label = { Text("Events") },
            selected = navController.currentDestination?.route == "events",
            onClick = {
                navController.navigate("events") {
                    popUpTo(navController.graph.startDestinationId)
                    launchSingleTop = true
                    restoreState = true
                }
            }
        )
    }
}

// Main screen placeholder
@Composable
fun MainScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(text = "Bienvenue sur l'application ISEN Smart Companion", style = MaterialTheme.typography.headlineMedium)
    }
}

// Preview function for design mode
@Preview(showBackground = true)
@Composable
fun PreviewApp() {
    ISENSmartCompanionTheme {
        AppNavigation()
    }
}
